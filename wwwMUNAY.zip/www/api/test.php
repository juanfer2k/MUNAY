<?php
echo "API funcionando";